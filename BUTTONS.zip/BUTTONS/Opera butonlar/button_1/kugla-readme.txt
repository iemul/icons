--------------------------------------------------------------------
BUTTON SET "KUGLA"
--------------------------------------------------------------------

To install this button set:


Create a new folder in your \Opera\Buttons directory and extract the
.zip file into it.

Then go to Opera's 'Preferences->Button and Status bar'. Under 'Buttons
- Image set', press the button to browse your drive for the new folder
that you just created. Inside this new button directory, you will find a
file named buttons.ini. Select it, and press 'OK'.

Now, I like it this way:

"Button Background" and "Background" same color.
[ ] Show Text
[ ] Show Border
[ ] Always show color
[x] Popup button description (if you don't see logic in graphics on buttons)

NOTE:Use light gray as a button background with this set!!! Default
Windows gray (R=192 G=192 B=192) works great.

------------------------------------------------------------------
                  Designed by Nikola Pizurica
           Comments are welcomed: pizurica@eunet.yu
Opera Button Set Page: http://solair.eunet.yu/~pizurica/dugme.htm
------------------------------------------------------------------

       YUGOSLAV BASEBALL ASSOCIATION  http://come.to/yba

------------------------------------------------------------------

NOTE:

Additional buttons to suit my usage of Opera 5 have been added - some of
these are default Opera buttons, where either they correspond to
functions I don't usually use, or where the defaults seemed to be fine.
Many have been adapted from the original kugla set, or from other
similar buttons.  I have not kept a proper account of attributions - I
hope none of the original creators will take offense.  This augmented
set is offered to other Opera users in a similar spirit of "sharing" -
adapt and adopt this set as you wish.  Thanks to Nikola for the
originals which are still the heart of this button set.

-= rags =-

<www.math.mcgill.ca/rags>


