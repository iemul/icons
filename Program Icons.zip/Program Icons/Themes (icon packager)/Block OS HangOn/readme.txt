
Block OS HangOn
===============

This lovely icon packager was originally made by Block (LineStudio) I just recolored it to match my HangOn skins suite. All the credits goes to his wonderful job.

Here a part of LineStudio's permission for me to port it:

"Please use my icon.
Please change my information written down with Readme documents.
URL:http://block.m78.com/
Thank you very much for selecting my icon.
Thanks!
LINEstudio"


    LineSudio Email: block@m10.alpha-net.ne.jp
 LineStudio Website: URL:http://block.m78.com/



      treetog Email: renatocveras@uol.com.br
    treetog Website: http://www.integration-worx.com
