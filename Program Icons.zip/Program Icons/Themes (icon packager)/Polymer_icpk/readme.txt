*********************************************************************************************************
    ____        __                         
   / __ \____  / /_  ______ ___  ___  _____
  / /_/ / __ \/ / / / / __ `__ \/ _ \/ ___/
 / ____/ /_/ / / /_/ / / / / / /  __/ /    
/_/    \____/_/\__, /_/ /_/ /_/\___/_/     
              /____/                       

 Polymer "The Suite" by The Skindicate
********************************************************************************************************* 
Release date 
October 07, 2000
                           
The Skindicate members ______________________________________________________________________________________

Russell Schwenkler   	-   aka Dangeruss-   www.dangeruss-industries.com
Deven Stephens     	-   aka Dmer	-    www.dangeruss-industries.com/doubled.shtm1 
Renato C. Veras Jr.	-   aka treetog	-    www.integration-worx.com

About Polymer Suite _________________________________________________________________________________________

The Polymer suite was the result of the ideas of three very different people. During 3 months of hard work, hundreds of e-mails  were sent, many hours were worked, lots of skins attempted and some abandoned, always thinking about just one target; doing our best to the skinning community.
 
This is the biggest suite of skins ever made so far. We tried to make skins for every kind of application, in some cases, more then one per kind, for the best desktop customization as possible.

All graphics works included in this suite are 100% originally created by us, inspired in nobodys ideas less then our own.

Polymer Contents ___________________________________________________________________________________________

THEMES:
	HoverDesk 		- by Dangeruss
	LiteStep 		- by Dmer
	NextStart/WorkShelf	- by treetog

WALLPAPER		- by Dangeruss

SKINS
	Beatnik 	- by Dangeruss/ by Dmer (two versions)
	BoxBar		- by treetog
	BoxChess	- by treetog	
	BoxFonts	- by treetog
	BoxIP		- by treetog
	BoxKeeper	- by Dmer
	BoxSpectra	- by treetog
	BoxZoom		- by treetog
	BuddyPhone	- by treetog
	ColorPad	- by treetog
	CoolPlayer	- by treetog
	Efx		- by treetog
	EuroCalculator	- by treetog
	EzPop		- by Dangeruss
	IcqPlus		- by treetog
	Ipanel		- by Dmer
	MadCow		- by treetog
	NeoPlanet	- by Dangeruss
	QuickNotes	- by Dmer	
	Scribbles	- by treetog
	SkinPad		- by Dmer
	Sysmeter 1.1	- by Dangeruss
	Sysmeter 2.03	- by Dangeruss
	TheClock	- by Dmer
	Windowblinds	- by treetog
	WinAmp		- by Dangeruss
	XX Calculator	- by treetog
	YAwN		- by Dmer

ICON PACKAGER		- by treetog

Contact __________________________________________________________________________________________________

If you have any question, bug report or suggestion, please, drop us an mail, it will be forwarded to the 3 of us.

theskindicate@dangeruss-industries.com
