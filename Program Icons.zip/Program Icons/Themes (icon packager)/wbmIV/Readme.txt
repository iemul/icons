WBManiaIV theme for Icon Packager.

More icons coming soon.

Design by:
Dmitry A. Kulinitch (aka -=D.A.K.=-), 2000.
dak@machaon.khmts.khabarovsk.su
ICQ#956737

